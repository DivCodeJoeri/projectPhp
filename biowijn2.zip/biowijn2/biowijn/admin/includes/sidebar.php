
<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <div class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-0">
            <svg height="50" width="50">

                <circle cx="24" cy="6" r="5"   fill="green" />
                <circle cx="36" cy="6" r="5"   fill="green" />
                <polygon points="24,8.5 20,3 10,9" style="fill:green;stroke:green;stroke-width:1"/>
                <polygon points="36,8.5 40,3 50,9" style="fill:green;stroke:green;stroke-width:1"/>
                <circle cx="15" cy="15" r="4"   fill="#0D206D" />
                <circle cx="25" cy="15" r="4"   fill="#0D206D" />
                <circle cx="35" cy="15" r="4"   fill="#0D206D" />
                <circle cx="45" cy="15" r="4"   fill="#0D206D" />
                <circle cx="20" cy="25" r="4"   fill="#0D206D" />
                <circle cx="30" cy="25" r="4"   fill="#0D206D" />
                <circle cx="40" cy="25" r="4"   fill="#0D206D" />
                <circle cx="25" cy="35" r="4"   fill="#0D206D" />
                <circle cx="35" cy="35" r="4"   fill="#0D206D" />
                <circle cx="30" cy="45" r="4"   fill="#0D206D" />
            </svg>
        </div>
        <div class="sidebar-brand-text mx-3">BIO WIJN</div>
    </div>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <span class="nav-link">Dashboard - BIO WIJN</span>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->


    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item p-1">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo1" aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-user"></i>
            <span>Beheerders</span>
        </a>
        <div id="collapseTwo1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="users.php">Alle beheerders</a>
                <a class="collapse-item" href="createUser.php">Beheerder toevoegen</a>
                <a class="collapse-item" href="editUser.php">Beheerder aanpassen</a>
                <a class="collapse-item" href="deleteUser.php">Beheerder verwijderen</a>
            </div>
        </div>
    </li>

    <li class="nav-item p-1">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-piggy-bank"></i>
            <span>Klanten</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="users.php">Alle klanten</a>
                <a class="collapse-item" href="createUser.php">Klant toevoegen</a>
                <a class="collapse-item" href="editUser.php">Klant aanpassen</a>
                <a class="collapse-item" href="deleteUser.php">Klant verwijderen</a>
            </div>
        </div>
    </li>

    <li class="nav-item p-1">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwoo" aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-glass-cheers"></i>
            <span>Producten</span>
        </a>
        <div id="collapseTwoo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="#">Alle producten</a>
                <a class="collapse-item" href="#">Product toevoegen</a>
                <a class="collapse-item" href="#">Product bewerken</a>
                <a class="collapse-item" href="#">Product verwijderen</a>
            </div>
        </div>
    </li>

    <li class="nav-item p-1">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwoooo" aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-camera"></i>
            <span>Foto's Producten</span>
        </a>
        <div id="collapseTwoooo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="photos.php">Alle foto's</a>
                <a class="collapse-item" href="#">Foto toevoegen</a>
                <a class="collapse-item" href="#">Foto bewerken</a>
                <a class="collapse-item" href="#">Foto verwijderen</a>
            </div>
        </div>
    </li>

    <li class="nav-item p-1">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwooooo" aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-folder-open"></i>
            <span>Orders</span>
        </a>
        <div id="collapseTwooooo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="users.php">Alle orders</a>
                <a class="collapse-item" href="createUser.php">Order toevoegen</a>
                <a class="collapse-item" href="editUser.php">Order bewerken</a>
                <a class="collapse-item" href="deleteUser.php">Order verwijderen</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">


</ul>
<!-- End of Sidebar -->