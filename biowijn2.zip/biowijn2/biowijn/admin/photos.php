<?php include ("includes/header.php"); ?>
<?php
if (!$session->is_signed_in()) {
    redirect('login.php');
}
$photos = Photo::find_all();
?>
<?php include ("includes/sidebar.php"); ?>
<?php include ("includes/content-top.php"); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h2><strong>Photos</strong>
                <abbr title="Add Photo"><a class="btn btn-primary" href="upload.php"><i
                            class="fas fa-images"></i></a></abbr>
            </h2>
            <hr>
            <table class="table table-header">
                <thead>
                <tr>
                    <th>Photo</th>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>File Name</th>
                    <th>Type</th>
                    <th>Size</th>
                    <th>Delete?</th>
                    <th>Wijzig?</th>
                    <th>View?</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($photos as $photo): ?>
                <tr>
                    <td><img src="<?php echo $photo->picture_path(); ?>" height="62" width="62" alt="picture"></td>
                    <td class="d-flex align-self-stretch"><?php echo $photo->id; ?></td>
                    <td><?php echo $photo->title; ?></td>
                    <td><?php echo $photo->description; ?></td>
                    <td><?php echo $photo->filename; ?></td>
                    <td><?php echo $photo->type; ?></td>
                    <td><?php echo $photo->size; ?></td>
                    <td><a class="btn btn-danger rounded-0" href="delete_photo.php?id=<?php echo
                        $photo->id; ?>"><i class="far fa-trash-alt"></i></a></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include ("includes/footer.php"); ?>
