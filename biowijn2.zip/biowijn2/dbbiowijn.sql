-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Gegenereerd op: 23 aug 2020 om 18:04
-- Serverversie: 8.0.18
-- PHP-versie: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbiowijn`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `beheerder`
--

DROP TABLE IF EXISTS `beheerder`;
CREATE TABLE IF NOT EXISTS `beheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `beheerder`
--

INSERT INTO `beheerder` (`id`, `first_name`, `last_name`, `username`, `password`, `role`) VALUES
(1, 'Joeri', 'Deketelaere', 'joeri', '123', 'admin'),
(2, 'Lala', 'NognogAnders', 'IQ', '123', 'ondergeschikte'),
(4, '', '', 'Lolly3', '123', ''),
(11, '', '', 'Lolly3', '', ''),
(12, '', '', 'Lolly3', '', ''),
(13, '', '', 'Lolly3', '', ''),
(14, '', '', 'Gelukt', '', ''),
(15, '', '', 'Gelukt', '', '');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `foto_product`
--

DROP TABLE IF EXISTS `foto_product`;
CREATE TABLE IF NOT EXISTS `foto_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `foto_product`
--

INSERT INTO `foto_product` (`id`, `title`, `description`, `filename`, `type`, `size`) VALUES
(1, 'rodefles.jpg', 'ghjfkd jkjsze', 'rodefles.jpg', 'jpg', 0),
(2, 'rodefles1.jpg', 'dehhfjg gjjfhh fgjhjfg fjghgh', 'rodefles1.jpg', 'jpg', 0),
(3, 'rosefles2.jpg', 'goedzo', 'rosefles2.jpg', 'jpg', 0),
(4, 'rosefles16.jpg', 'hjkgjd', 'rosefles16.jpg', 'jpg', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klant`
--

DROP TABLE IF EXISTS `klant`;
CREATE TABLE IF NOT EXISTS `klant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(11) NOT NULL,
  `last_name` varchar(11) NOT NULL,
  `straat` varchar(11) NOT NULL,
  `huisnummer` varchar(11) NOT NULL,
  `woonplaats` varchar(11) NOT NULL,
  `postcode` varchar(11) NOT NULL,
  `land` varchar(255) NOT NULL,
  `geboortedatum` varchar(11) NOT NULL,
  `email` varchar(11) NOT NULL,
  `telefoon` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `klant`
--

INSERT INTO `klant` (`id`, `username`, `password`, `first_name`, `last_name`, `straat`, `huisnummer`, `woonplaats`, `postcode`, `land`, `geboortedatum`, `email`, `telefoon`) VALUES
(1, 'joeri', '123', 'Joeri', 'Deketelaere', 'Kortweg', '1', 'Brug', '0000', '', '01.01.2025', 'ghjh@gmail.', '000001');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `klanten_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  PRIMARY KEY (`id`,`klanten_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `order_product`
--

DROP TABLE IF EXISTS `order_product`;
CREATE TABLE IF NOT EXISTS `order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hoeveelheid` int(255) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `prijs` decimal(65,0) NOT NULL,
  `voorraad` int(150) NOT NULL,
  `land` varchar(255) NOT NULL,
  `kleur` varchar(255) NOT NULL,
  `omschrijving` varchar(255) NOT NULL,
  `product_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `product`
--

INSERT INTO `product` (`id`, `name`, `prijs`, `voorraad`, `land`, `kleur`, `omschrijving`, `product_image`) VALUES
(1, 'chateau migraine', '15', 10, 'Frankrijk-Bordeaux', 'rood', 'fkgkfkgk gkhjfjddk', 'rodefles.jpg'),
(2, 'chateau migraine', '11', 5, '', '', '', ''),
(3, 'Chateau De Pomerol', '145', 25, 'Frankrijk-Pomerol', 'rood', 'Krijg je minder snel pijn van in je hoofd', 'rodefles1.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
